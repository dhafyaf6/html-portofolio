#include <iostream>
using namespace std;
int main() {
    // Deklarasi dan inisialisasi array(ibaratkan kotak yang bisa menyimpan banyak nilai)
    int angka[5];
    //isi kotak satu per satu
    angka[0] = 10;
    angka[1] = 20;
    angka[2] = 15;
    angka[3] = 40;
    angka[4] = 30;
//menampilkan isi kotak nomor 0 (data pertama)
    for (int i = 0; i < 5; i++) {
        cout << "Angka ke-" << (i + 1) << ": " << angka[i] << endl;
    }

    return 0;
}