#include <iostream>
using namespace std;
int main() {
    //langsung buat dan isi sekaligus
    int angka[] = {10, 20, 15, 40, 30};
    //menampilkan semua isi menggunakan perulangan(looping)
    for (int i = 0; i < 5; i++) {
        cout << "Angka ke-" << (i + 1) << ": " << angka[i] << endl;
    }

    return 0;
}