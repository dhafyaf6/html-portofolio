#include <iostream>

int main() {
    // Deklarasi dan inisialisasi variabel angka
    int angka1 = 10;
    int angka2 = 20;
    int angka3 = 15;
    int angka4 = 40;
    int angka5 = 30;
    // Menampilkan angka-angka tersebut(terpisah/dipanggil satu per satu)
    std::cout << "Angka pertama: " << angka1 << std::endl;
    std::cout << "Angka kedua: " << angka2 << std::endl;
    std::cout << "Angka ketiga: " << angka3 << std::endl;
    std::cout << "Angka keempat: " << angka4 << std::endl;
    std::cout << "Angka kelima: " << angka5 << std::endl;

    return 0;
}