#include <iostream>
#include <string> //untuk menggunakan tipe data string
using namespace std;
int main() {
    // langsung mengisi dengan sekaligus
    string buah[5] = {"Mangga", "Apel", "Pisang", "Jeruk", "Semangka"};
    // menampilkan semua isi menggunakan perulangan
    for (int i = 0; i < 5; i++) {
        cout << "Buah ke-" << (i + 1) << ": " << buah[i] << endl;
    }
    return 0;
}