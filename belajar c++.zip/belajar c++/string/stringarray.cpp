#include <iostream>
#include <string> //ini wajib untuk menggunakan tipe data string :)
using namespace std;
int main() {
    string buah [5];// mendeklarasikan array string dengan nama buah dan ukuran 5
    // isi satupersatu tanpa menggunakan(menuliskan) string lagi
    buah[0] = "Mangga";
    buah[1] = "Apel";
    buah[2] = "Pisang";
    buah[3] = "Jeruk";
    buah[4] = "Semangka";
    // menampilkan nama buah yang telah disimpan dalam array menggunakan perulangan for
    for (int i = 0; i < 5; i++) {
        cout << "Buah ke-" << (i + 1) << ": " << buah[i] << endl;
    }
    return 0;
}