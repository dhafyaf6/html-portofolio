#include <iostream>
#include <string>// wajib ini untuk menggunakan tipe data string
using namespace std;
int main() {
    // Mendeklarasikan beberapa variabel string untuk menyimpan nama buah
    string buah1 = "Apel";
    string buah2 = "Pisang";
    string buah3 = "Mangga";
    string buah4 = "Jeruk";
    string buah5 = "Anggur";
    // Menampilkan nama buah yang telah disimpan dalam variabel
    cout << "Buah pertama: " << buah1 << endl;
    cout << "Buah kedua: " << buah2 << endl;
    cout << "Buah ketiga: " << buah3 << endl;
    cout << "Buah keempat: " << buah4 << endl;
    cout << "Buah kelima: " << buah5 << endl;
    return 0;
}